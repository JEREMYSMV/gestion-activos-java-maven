package proyect.packages;

import proyect.packages.dao.EmpleadoDAO;
import proyect.packages.model.Empleado;
import proyect.packages.model.EstadoActivo;

import java.util.List;

public class Main {

    public static void main(String[] args) {

        EmpleadoDAO empleadoDAO = new EmpleadoDAO();

        // Crear empleado 1
        Empleado empleado1 = new Empleado();
        empleado1.setNombre("Carlos");
        empleado1.setArea("Sistemas");
        empleado1.setSueldo(2500.00);
        empleado1.setEstado("Activo");

        // Crear empleado 2
        Empleado empleado2 = new Empleado();
        empleado2.setNombre("Maria");
        empleado2.setArea("Recursos Humanos");
        empleado2.setSueldo(2800.00);
        empleado2.setEstado("Activo");

        int idEmpleado1 = empleadoDAO.crear(empleado1);
        int idEmpleado2 = empleadoDAO.crear(empleado2);

        // Mostrar empleados
        System.out.println("\n===== EMPLEADOS CREADOS =====");

        mostrarEmpleados(empleadoDAO.listar());

        // Editar sueldo del primer empleado
        empleadoDAO.actualizarSueldo(idEmpleado1, 3000.00);

        // Editar estado del segundo empleado
        empleadoDAO.actualizarEstado(idEmpleado2, "Inactivo");

        // Mostrar empleados actualizados
        System.out.println("\n===== EMPLEADOS ACTUALIZADOS =====");

        mostrarEmpleados(empleadoDAO.listar());

        // Eliminar los dos empleados
        empleadoDAO.eliminar(idEmpleado1);
        empleadoDAO.eliminar(idEmpleado2);

        // Mostrar que no quedan empleados
        System.out.println("\n===== EMPLEADOS DESPUES DE ELIMINAR =====");

        List<Empleado> empleados = empleadoDAO.listar();

        if (empleados.isEmpty()) {
            System.out.println("No hay ningun empleado registrado.");
        } else {
            mostrarEmpleados(empleados);
        }

        // PRUEBA DE LA CLASE ESTADOACTIVO
        EstadoActivo estado = new EstadoActivo(
                1,
                "En Almacén",
                "El activo se encuentra operativo y en el almacén."
        );
        System.out.println("\n=====ESTADO ACTIVO PRUEBA====");
        System.out.println("ID: " + estado.getIdEstado());
        System.out.println("Nombre: " + estado.getNombre());
        System.out.println("Descripción: " + estado.getDescripcion());
    }

    //MUESTRA A LOS EMPLEADOS DE LA TABLA
    public static void mostrarEmpleados(List<Empleado> empleados) {

        for (Empleado empleado : empleados) {

            System.out.println(
                    "ID: " + empleado.getIdEmpleado()
                            + " | Nombre: " + empleado.getNombre()
                            + " | Area: " + empleado.getArea()
                            + " | Sueldo: S/ " + empleado.getSueldo()
                            + " | Estado: " + empleado.getEstado()
            );
        }
    }
}