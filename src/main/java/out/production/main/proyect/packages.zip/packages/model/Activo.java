package proyect.packages.model;

public class Activo {

    private int id;
    private String nombre;
    private String marca;
    private String NroSerie;
    private String estado;

    public int getId() {
        return id;
    }

    public void setId(int idActivo) {
        this.id = idActivo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getNroSerie() {
        return NroSerie;
    }

    public void setNroSerie(String nro_serie) {
        this.NroSerie = nro_serie;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}